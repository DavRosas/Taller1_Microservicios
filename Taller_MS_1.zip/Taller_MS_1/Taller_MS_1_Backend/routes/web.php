<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('/ingresos', 'IngresoController@index');
$router->post('/ingresos', 'IngresoController@store');
$router->get('/ingresos/{id}', 'IngresoController@show');
$router->put('/ingresos/{id}', 'IngresoController@update');
$router->delete('/ingresos/{id}', 'IngresoController@destroy');

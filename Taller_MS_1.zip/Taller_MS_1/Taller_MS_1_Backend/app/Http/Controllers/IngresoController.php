<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ingreso;

class IngresoController extends Controller
{
    public function index()
    {
        $ingresos = Ingreso::all();
        return response()->json($ingresos);
    }

    public function store(Request $request)
    {
        $datos = $request->all();

        // Combina fecha y hora para validación
        $fechaIngreso = $datos['fechaIngreso'] . ' ' . $datos['horaIngreso'];

        // Verifica que la fecha y hora estén en el rango permitido
        if (!$this->esHoraValida($fechaIngreso)) {
            return response()->json(['error' => 'Hora de ingreso fuera del rango permitido'], 400);
        }

        if (isset($datos['horaSalida'])) {
            $fechaSalida = $datos['fechaIngreso'] . ' ' . $datos['horaSalida'];
            if (!$this->esHoraValida($fechaSalida)) {
                return response()->json(['error' => 'Hora de salida fuera del rango permitido'], 400);
            }
        }

        $ingreso = Ingreso::create($datos);
        return response()->json($ingreso, 201);
    }

    public function show($id)
    {
        $ingreso = Ingreso::findOrFail($id);
        return response()->json($ingreso);
    }

    public function update(Request $request, $id)
    {
        $datos = $request->all();

        // Combina fecha y hora para validación
        $fechaIngreso = $datos['fechaIngreso'] . ' ' . $datos['horaIngreso'];

        // Verifica que la fecha y hora estén en el rango permitido
        if (!$this->esHoraValida($fechaIngreso)) {
            return response()->json(['error' => 'Hora de ingreso fuera del rango permitido'], 400);
        }

        if (isset($datos['horaSalida'])) {
            $fechaSalida = $datos['fechaIngreso'] . ' ' . $datos['horaSalida'];
            if (!$this->esHoraValida($fechaSalida)) {
                return response()->json(['error' => 'Hora de salida fuera del rango permitido'], 400);
            }
        }

        $ingreso = Ingreso::findOrFail($id);
        $ingreso->update($datos);

        return response()->json($ingreso);
    }

    public function destroy($id)
    {
        $ingreso = Ingreso::findOrFail($id);
        $ingreso->delete();
        return response()->json(null, 204);
    }

    // Método para validar que la hora está en el rango permitido
    private function esHoraValida($fechaHora)
    {
        $timestamp = strtotime($fechaHora);
        $diaSemana = date('w', $timestamp);
        $hora = date('H:i:s', $timestamp);

        if ($diaSemana >= 1 && $diaSemana <= 5) { // Lunes a Viernes
            return $hora >= '07:00:00' && $hora <= '20:50:00';
        } elseif ($diaSemana == 6) { // Sábado
            return $hora >= '07:00:00' && $hora <= '16:30:00';
        } else { // Domingo
            return false;
        }
    }
}
